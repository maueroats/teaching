
# apcs-01-connect-four 

* Please replace the `connect-four.hs` file with your own code.
* Make sure it prints out your name when you run it.
* Note anything that is incomplete / does not work in comments.


