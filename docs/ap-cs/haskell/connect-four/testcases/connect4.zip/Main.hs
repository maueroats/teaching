module Main where
    
import qualified TestConnectFour as Thing
-- import qualified UIConnectFour as Thing


main = Thing.main
       
